'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Menu, Mail, ShoppingCart, LogOut, Search, ChevronRight, ChevronUp, DollarSign, ArrowRightLeft, Camera, PieChart } from 'lucide-react';

export default function Dashboard2() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [balance, setBalance] = useState(0);
  const [savingsBalance, setSavingsBalance] = useState(0);
  const [bankingExpanded, setBankingExpanded] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const userEmail = localStorage.getItem('userEmail');
    const role = localStorage.getItem('userRole');
    if (!userEmail || role !== 'user') {
      router.push('/');
      return;
    }
    setEmail(userEmail);
    loadAccount(userEmail);
  }, []);

  const loadAccount = async (userEmail: string) => {
    const res = await fetch(`/api/accounts?email=${userEmail}`);
    const data = await res.json();
    if (data.balance !== undefined) {
      setBalance(data.balance);
      setSavingsBalance(data.balance * 0.15);
      const capitalizedName = data.name.split(' ').map((word: string) => 
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      ).join(' ');
      setName(capitalizedName);
    }
  };

  const logout = () => {
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userRole');
    router.push('/');
  };

  return (
    <>
      <style jsx>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .app-container {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          background: #F4F4F4;
          min-height: 100vh;
          padding-bottom: 80px;
        }

        .top-nav {
          background: white;
          padding: 16px 20px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .nav-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
        }

        .menu-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          background: none;
          border: none;
          cursor: pointer;
          color: #333;
        }

        .menu-label {
          font-size: 11px;
          color: #333;
        }

        .quick-actions {
          display: flex;
          gap: 24px;
        }

        .action-btn {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          background: none;
          border: none;
          cursor: pointer;
          color: #333;
        }

        .action-label {
          font-size: 11px;
          color: #333;
        }

        .search-row {
          display: flex;
          gap: 12px;
          align-items: center;
          margin-bottom: 16px;
        }

        .search-pill {
          flex: 1;
          background: #EAEAEA;
          border-radius: 24px;
          padding: 12px 16px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .search-pill input {
          flex: 1;
          background: none;
          border: none;
          outline: none;
          color: #555;
          font-size: 14px;
        }

        .erica-btn {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: #E31837;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: white;
        }

        .tabs {
          display: flex;
          border-bottom: 1px solid #E5E7EB;
        }

        .tab {
          flex: 1;
          padding: 12px;
          text-align: center;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.5px;
          cursor: pointer;
          border: none;
          background: none;
          position: relative;
        }

        .tab.active {
          color: #E31837;
        }

        .tab.active::after {
          content: '';
          position: absolute;
          bottom: -1px;
          left: 0;
          right: 0;
          height: 3px;
          background: #E31837;
        }

        .tab.inactive {
          color: #6B7280;
        }

        .content {
          padding: 16px;
        }

        .card {
          background: white;
          border-radius: 12px;
          margin-bottom: 16px;
          box-shadow: 0 4px 6px rgba(0,0,0,0.05);
          overflow: hidden;
        }

        .card-row {
          padding: 16px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          cursor: pointer;
          border-bottom: 1px solid #F3F4F6;
        }

        .card-row:last-child {
          border-bottom: none;
        }

        .card-row:hover {
          background: #F9FAFB;
        }

        .row-left {
          flex: 1;
        }

        .row-title {
          font-size: 16px;
          font-weight: 700;
          color: #111827;
          margin-bottom: 4px;
        }

        .row-subtitle {
          font-size: 13px;
          color: #6B7280;
        }

        .banking-accent {
          height: 4px;
          background: linear-gradient(to right, #E31837 60%, #012169 60%);
        }

        .banking-header {
          padding: 16px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          cursor: pointer;
          border-bottom: 1px solid #F3F4F6;
        }

        .banking-title {
          font-size: 18px;
          font-weight: 700;
          color: #111827;
        }

        .bank-identity {
          padding: 16px 20px;
          display: flex;
          align-items: center;
          gap: 12px;
          border-bottom: 1px solid #F3F4F6;
        }

        .bank-name {
          font-size: 16px;
          font-weight: 700;
          color: #111827;
        }

        .bank-logo {
          display: flex;
          gap: 2px;
        }

        .logo-stripe {
          width: 8px;
          height: 20px;
          border-radius: 2px;
        }

        .fdic-row {
          padding: 12px 20px;
          border-bottom: 1px solid #F3F4F6;
        }

        .fdic-text {
          font-size: 12px;
          font-weight: 700;
          color: #012169;
          margin-bottom: 4px;
        }

        .fdic-disclaimer {
          font-size: 10px;
          color: #6B7280;
          font-style: italic;
        }

        .account-row {
          padding: 16px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid #F3F4F6;
          cursor: pointer;
        }

        .account-row:hover {
          background: #F9FAFB;
        }

        .account-name {
          font-size: 15px;
          color: #111827;
        }

        .account-balance {
          font-size: 16px;
          font-weight: 700;
          color: #111827;
          margin-right: 8px;
        }

        .promo-card {
          padding: 20px;
        }

        .promo-top {
          display: flex;
          gap: 16px;
          margin-bottom: 20px;
        }

        .promo-icon {
          width: 60px;
          height: 60px;
          background: #012169;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          transform: rotate(-5deg);
          flex-shrink: 0;
        }

        .promo-text {
          flex: 1;
        }

        .promo-headline {
          font-size: 18px;
          font-weight: 700;
          color: #111827;
          margin-bottom: 8px;
        }

        .promo-body {
          font-size: 14px;
          color: #6B7280;
          line-height: 1.5;
        }

        .promo-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          border-top: 1px solid #F3F4F6;
          padding-top: 16px;
          gap: 1px;
        }

        .promo-btn {
          padding: 12px;
          text-align: center;
          font-size: 13px;
          font-weight: 700;
          letter-spacing: 0.5px;
          color: #0055C4;
          background: none;
          border: none;
          cursor: pointer;
        }

        .promo-btn:first-child {
          border-right: 1px solid #F3F4F6;
        }

        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: white;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          box-shadow: 0 -2px 8px rgba(0,0,0,0.1);
          padding: 8px 0;
        }

        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 8px;
          background: none;
          border: none;
          cursor: pointer;
        }

        .nav-item.active {
          color: #0055C4;
        }

        .nav-item.inactive {
          color: #555;
        }

        .nav-label {
          font-size: 10px;
          font-weight: 600;
        }

        .icon-circle {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .icon-circle.active {
          background: #0055C4;
          color: white;
        }

        .icon-circle.inactive {
          border: 2px solid #555;
          color: #555;
        }
      `}</style>

      <div className="app-container">
        {/* Top Navigation */}
        <div className="top-nav">
          <div className="nav-row">
            <button className="menu-btn">
              <Menu size={24} />
              <span className="menu-label">Menu</span>
            </button>
            <div className="quick-actions">
              <button className="action-btn">
                <Mail size={20} />
                <span className="action-label">Inbox</span>
              </button>
              <button className="action-btn">
                <ShoppingCart size={20} />
                <span className="action-label">Products</span>
              </button>
              <button className="action-btn" onClick={logout}>
                <LogOut size={20} />
                <span className="action-label">Log Out</span>
              </button>
            </div>
          </div>

          <div className="search-row">
            <div className="search-pill">
              <Search size={18} color="#555" />
              <input type="text" placeholder="Hi, I'm Erica. May I help?" />
            </div>
            <button className="erica-btn">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M4 8C4 8 6 6 12 6C18 6 20 8 20 8" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                <path d="M4 12C4 12 6 10 12 10C18 10 20 12 20 12" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                <path d="M4 16C4 16 6 14 12 14C18 14 20 16 20 16" stroke="white" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          <div className="tabs">
            <button className="tab active">ACCOUNTS</button>
            <button className="tab inactive">DASHBOARD</button>
          </div>
        </div>

        {/* Content */}
        <div className="content">
          {/* Life Plan & Rewards Card */}
          <div className="card">
            <div className="card-row">
              <div className="row-left">
                <div className="row-title">Bank of America Life Plan®</div>
                <div className="row-subtitle">Set, track, achieve. Your goals are in reach.</div>
              </div>
              <ChevronRight size={20} color="#6B7280" />
            </div>
            <div className="card-row">
              <div className="row-left">
                <div className="row-title">My Rewards</div>
              </div>
              <ChevronRight size={20} color="#6B7280" />
            </div>
          </div>

          {/* Banking Card */}
          <div className="card">
            <div className="banking-accent"></div>
            <div className="banking-header" onClick={() => setBankingExpanded(!bankingExpanded)}>
              <div className="banking-title">Banking</div>
              {bankingExpanded ? <ChevronUp size={20} color="#6B7280" /> : <ChevronRight size={20} color="#6B7280" />}
            </div>
            
            {bankingExpanded && (
              <>
                <div className="bank-identity">
                  <div className="bank-name">Bank of America</div>
                  <div className="bank-logo">
                    <div className="logo-stripe" style={{ background: '#E31837' }}></div>
                    <div className="logo-stripe" style={{ background: '#E31837' }}></div>
                    <div className="logo-stripe" style={{ background: '#012169' }}></div>
                  </div>
                </div>

                <div className="fdic-row">
                  <div className="fdic-text">FDIC</div>
                  <div className="fdic-disclaimer">FDIC-Insured - Backed by the full faith and credit of the U.S. Government</div>
                </div>

                <div className="account-row">
                  <div className="account-name">{name || 'Ahmonte'}</div>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div className="account-balance">- ${balance.toFixed(2)}</div>
                    <ChevronRight size={20} color="#6B7280" />
                  </div>
                </div>

                <div className="account-row">
                  <div className="account-name">Advantage Savings - 2501</div>
                  <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div className="account-balance">${savingsBalance.toFixed(2)}</div>
                    <ChevronRight size={20} color="#6B7280" />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Promotional Card */}
          <div className="card">
            <div className="promo-card">
              <div className="promo-top">
                <div className="promo-icon">
                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <rect x="8" y="4" width="16" height="20" fill="white" rx="2"/>
                    <line x1="10" y1="8" x2="18" y2="8" stroke="#E31837" strokeWidth="2"/>
                    <line x1="10" y1="11" x2="18" y2="11" stroke="#E31837" strokeWidth="2"/>
                    <path d="M10 14L12 16L18 10" stroke="#E31837" strokeWidth="2" fill="none"/>
                    <line x1="10" y1="18" x2="18" y2="18" stroke="#0055C4" strokeWidth="2"/>
                    <line x1="10" y1="21" x2="18" y2="21" stroke="#0055C4" strokeWidth="2"/>
                  </svg>
                </div>
                <div className="promo-text">
                  <div className="promo-headline">There's more to explore</div>
                  <div className="promo-body">
                    Explore Bank of America credit cards, loans, checking and savings accounts, plus Merrill investment solutions.
                  </div>
                </div>
              </div>
              <div className="promo-actions">
                <button className="promo-btn">OFFERS</button>
                <button className="promo-btn">PRODUCTS</button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <nav className="bottom-nav">
          <button className="nav-item active">
            <div className="icon-circle active">
              <DollarSign size={18} />
            </div>
            <span className="nav-label">Accounts</span>
          </button>
          <button className="nav-item inactive">
            <div className="icon-circle inactive">
              <ArrowRightLeft size={18} />
            </div>
            <span className="nav-label">Pay & Transfer</span>
          </button>
          <button className="nav-item inactive">
            <div className="icon-circle inactive">
              <Camera size={18} />
            </div>
            <span className="nav-label">Deposit Checks</span>
          </button>
          <button className="nav-item inactive">
            <div className="icon-circle inactive">
              <PieChart size={18} />
            </div>
            <span className="nav-label">Invest</span>
          </button>
        </nav>
      </div>
    </>
  );
}
